<?php
/*
Plugin Name: Konwerter Planu Lekcji
Description: Konwertuje pliki planu lekcji na strony WordPress i łączy je ze sobą. Ma również stronę ustawień.
Version: 2.4
Author: Damian Wałach
*/

function my_plugin_enqueue_scripts() {
    // Sprawdź, czy skrypt istnieje
    if (file_exists(plugin_dir_path(__FILE__) . 'menu.js')) {
        wp_enqueue_script(
            'custom-menu-script', // Handle skryptu
            plugins_url('menu.js', __FILE__), // Ścieżka do skryptu
            array(), // Tablica zależności
            null, // Numer wersji
            false // Ładowanie w stopce
        );
    } else {
        error_log('menu.js nie istnieje w katalogu wtyczki.');
    }
}
add_action('wp_enqueue_scripts', 'my_plugin_enqueue_scripts');


require 'wp-guard/src/WpGuard.php';

$guard = new Anystack\WpGuard\V001\WpGuard(
	__FILE__,
	[
		'api_key' => 'dR7xvZ22UI4uP126t8YQuPprc35RyyQm',
		'product_id' => '9cca30c7-cbe4-4dff-b04f-37ddcdc2fcb8',
		'product_name' => 'plugin',
		'license' => [
			'require_email' => false,
		],
		'updater' => [
			'enabled' => true,
		]
	]
);

$guard->validCallback(function() {
// Dodaj akcję dla strony administracyjnej WordPress
add_action('admin_menu', 'dodaj_strony_menu_wtyczki');
});

// Dodaj obsługę drukowania treści tylko z określonej klasy
add_action('wp_footer', 'dodaj_obszar_do_druku_na_stronie');

function dodaj_obszar_do_druku_na_stronie() {
    global $post;

    // Sprawdź, czy mamy do czynienia ze stroną
    if (is_a($post, 'WP_Post')) {
        // Pobierz treść strony
        $post_content = $post->post_content;

        // Znajdź obszar przeznaczony do drukowania
        preg_match('/<div class="content-container site-container".*?>(.*?)<\/div>/s', $post_content, $matches);

        // Sprawdź, czy znaleziono obszar
        if (!empty($matches[0])) {
            // Dodaj znacznik div wokół treści do drukowania
            echo '<div id="drukowany-obszar">' . implode('', array_filter($matches)) . '</div>';
        }
    }
}

function dodaj_strony_menu_wtyczki() {
    add_menu_page('Konwerter Planu Lekcji', 'Konwerter Planu Lekcji', 'manage_options', 'konwerter-planu-lekcji', 'render_strony_konwertera');
    add_submenu_page('konwerter-planu-lekcji', 'Ustawienia', 'Ustawienia', 'manage_options', 'konwerter-planu-lekcji-ustawienia', 'render_strony_ustawien_wtyczki');
    add_submenu_page('konwerter-planu-lekcji', 'Usuń Strony', 'Usuń Strony', 'manage_options', 'konwerter-planu-lekcji-usun-strony', 'render_strony_usun_strony');
}

add_action('admin_post_confirm_conversion', 'potwierdzenie_i_usuniecie');

function potwierdzenie_i_usuniecie() {
    // Rozpocznij sesję
    if (!session_id()) {
        session_start();
    }

    // Wykonaj operacje potwierdzenia i usunięcia
    usun_wszystkie_skonwertowane_strony();
    skonwertuj_pliki();

    // Ustaw flagę informującą o pomyślnym wykonaniu operacji
    $_SESSION['potwierdzenie_i_usuniecie_wykonane'] = true;

    // Pobierz URL strony, z której został wykonany post
	$previous_url = admin_url('admin.php?page=konwerter-planu-lekcji');

    // Przekieruj użytkownika z powrotem do poprzedniej strony
    wp_redirect($previous_url);
    exit;
}

// Dodaj komunikat o pomyślnym zastąpieniu planu tylko gdy operacja została wykonana
add_action('admin_notices', 'wyswietl_komunikat_po_potwierdzeniu');

function wyswietl_komunikat_po_potwierdzeniu() {
    // Sprawdź, czy sesja jest uruchomiona
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    // Sprawdź, czy flaga została ustawiona
    if (isset($_SESSION['potwierdzenie_i_usuniecie_wykonane']) && $_SESSION['potwierdzenie_i_usuniecie_wykonane']) {
        echo '<div class="notice notice-success is-dismissible">';
        echo '<p>Pomyślnie zastąpiono obecny plan.</p>';
        echo '</div>';

        // Usuń flagę z sesji po wyświetleniu komunikatu
        unset($_SESSION['potwierdzenie_i_usuniecie_wykonane']);
    }
}


function czy_sa_skonwertowane_strony() {
    $konwertowane_strony = get_option('konwertowane_strony', array());
    return !empty($konwertowane_strony);
}



function render_strony_konwertera() {
    ?>
    <div class="wrap">
        <h1 style="color: #2B6CB0; margin-top: 50px;">Konwerter Planu Lekcji</h1>

        <?php
        if (isset($_POST['submit_conversion'])) {
            // Sprawdź, czy są już skonwertowane strony
            if (czy_sa_skonwertowane_strony()) {
                ?>
                <script>
                    // Wywołaj funkcję tylko gdy użytkownik potwierdzi
                    if (confirm('Czy chcesz zastąpić obecny plan nowym?')) {
                        // Przekieruj użytkownika do strony potwierdzenia
                        window.location.href = "<?php echo admin_url('admin-post.php?action=confirm_conversion');?>";
                    }
                </script>
                <?php
            } else {
                // Jeśli nie, wykonaj konwersję plików bez dodatkowego pytania
                skonwertuj_pliki();
            }
        }
        ?>

		<!-- Formularz potwierdzenia -->
		<form method="post" action="">
			<input type="submit" name="submit_conversion" value="Skonwertuj plan" class="button-primary">
		</form>
    </div>
    <?php
}




function render_strony_ustawien_wtyczki() {
    ?>
    <div class="wrap">
        <h1 style="color: #2B6CB0; margin-top: 50px;">Ustawienia Konwertera Planu Lekcji</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('konwerter-planu-lekcji-ustawienia');
            do_settings_sections('konwerter-planu-lekcji-ustawienia');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

function render_strony_usun_strony() {
    ?>
    <div class="wrap">
        <h1 style="color: #FF0000; margin-top: 50px;">Usuń Skonwertowane Strony</h1>
        <form method="post">
            <input type="submit" name="usun_wszystkie_strony" value="Usuń wszystkie skonwertowane strony" onclick="return confirm('Czy na pewno chcesz usunąć wszystkie skonwertowane strony?');" style="color: #FF0000;">
        </form>
    </div>
    <?php
}

add_action('admin_init', 'inicjalizuj_strone_ustawien');

function inicjalizuj_strone_ustawien() {
    add_settings_section(
        'konwerter-planu-lekcji-ustawienia',
        'Ustawienia',
        'render_sekcji_ustawien',
        'konwerter-planu-lekcji-ustawienia'
    );

    add_settings_field(
        'data_obowiazywania',
        'Data obowiązywania planu',
        'render_pola_data',
        'konwerter-planu-lekcji-ustawienia',
        'konwerter-planu-lekcji-ustawienia'
    );


    register_setting('konwerter-planu-lekcji-ustawienia', 'data_obowiazywania', 'sanitize_date');
}



function render_sekcji_ustawien() {
    echo 'Ustawienia dotyczące konwertera planu lekcji.';
}

function render_pola_data() {
    $data_obowiazywania = esc_attr(get_option('data_obowiazywania'));
    echo '<input type="date" name="data_obowiazywania" value="' . $data_obowiazywania . '">';
}

function sanitize_date($date) {
    $new_date = date('d-m-Y', strtotime($date));

    // Sprawdź, czy data jest poprawna
    if (strtotime($new_date) === false) {
        add_settings_error(
            'data_obowiazywania',
            'invalid_date',
            'Błąd: Proszę wprowadzić poprawną datę.',
            'error'
        );
        return get_option('data_obowiazywania'); // Zwróć poprzednią wartość
    }

    return $new_date;
}



function pobierz_menu_lewe() {
    $sciezka_do_menu = WP_CONTENT_DIR . '/uploads/timetable/lista.html';

    // Sprawdź, czy plik menu istnieje
    if (!file_exists($sciezka_do_menu)) {
        echo '<p class="error">Błąd: Plik menu "lista.html" nie istnieje.</p>';
        return '';
    }

    // Pobierz zawartość menu
    $menu_html = file_get_contents($sciezka_do_menu);

    // Zastosuj funkcję zmieniającą linki w treści menu
    $menu_html_modified = zmien_linki_w_menu($menu_html);

    // Zastosuj dodatkowe przekształcenia
    $menu_html_modified = przeksztalc_menu($menu_html_modified);

    return $menu_html_modified;
}

function przeksztalc_menu($menu_html) {
    $sections = array('Oddziały', 'Nauczyciele', 'Sale');
    $section_ids = array('oddzialy', 'nauczyciele', 'sale');

    foreach ($sections as $index => $section_name) {
        $section_id = $section_ids[$index];

        $menu_html = preg_replace_callback(
            '/<h4>(.*?)' . preg_quote($section_name, '/') . '<\/h4>/iu',
            function($matches) use ($section_name, $section_id) {
                return "<h4 onclick=\"toggle('{$section_id}')\" class=\"toggle-header\" style=\"text-align: center; margin-top: 15px;\">{$matches[1]}{$section_name}</h4><hr style=\"height: 5px; background: gray; margin: 0;\">";
            },
            $menu_html
        );
    }

    $menu_html = preg_replace_callback(
        '/<ul>/', 
        function($matches) {
            static $section_ids = array('oddzialy', 'nauczyciele', 'sale');
            static $counter = 0;

            $section_id = $section_ids[$counter++];
            return "<ul id=\"$section_id\" class=\"toggle-list\">";
        }, 
        $menu_html
    );

    // Usuń niechciane linie HTML
    $tags_to_remove = array(
        '<html>',
        '<head>',
        '<meta http-equiv="Content-Type" content="text/html; charset=utf-8">',
        '<meta http-equiv="Content-Language" content="pl">',
        '<meta name="description" content=". Lista oddziałów, nauczycieli i sal utworzona za pomoc± programu Plan lekcji Optivum firmy VULCAN">',
        '<title>Lista oddziałów, nauczycieli i sal</title>',
        '<link rel="stylesheet" href="css/lista.css" type="text/css">',
        '<script language="JavaScript1.2" type="text/javascript" src="scripts/plan.js"></script>',
        '</head>',
        '<body>',
        '</body>',
        '</html>',
    );

    foreach ($tags_to_remove as $tag) {
        $menu_html = str_replace($tag, '', $menu_html);
    }

    return $menu_html;
}

function skonwertuj_pliki() {
    $sciezka_katalogu = WP_CONTENT_DIR . '/uploads/timetable/';

    // Sprawdź, czy katalog istnieje
    if (!file_exists($sciezka_katalogu)) {
        echo '<p class="error">Błąd: Katalog nie istnieje.</p>';
        return;
    }

    // Pobierz listę plików z katalogu
    $pliki = glob($sciezka_katalogu . '*.html');

    // Sprawdź, czy są jakiekolwiek pliki do konwersji
    if (empty($pliki)) {
        echo '<p class="error">Błąd: Brak plików do konwersji w katalogu.</p>';
        return;
    }

    // Sprawdź, czy plik "lista.html" istnieje
    $sciezka_do_menu = WP_CONTENT_DIR . '/uploads/timetable/lista.html';
    if (!file_exists($sciezka_do_menu)) {
        echo '<p class="error">Błąd: Plik menu "lista.html" nie istnieje.</p>';
        return;
    }

    // Konwertuj każdy plik (pomijając plik "lista.html")
    foreach ($pliki as $plik) {
        $nazwa_pliku = pathinfo($plik, PATHINFO_FILENAME);

        // Pomijaj plik "lista.html"
        if ($nazwa_pliku === 'lista') {
            continue;
        }

        $imie_nauczyciela = pobierz_imie_nauczyciela_z_pliku($plik);

        // Dodaj sprawdzenie przed wywołaniem funkcji konwertuj_plik
        if (file_exists($sciezka_do_menu)) {
            konwertuj_plik($plik, $imie_nauczyciela);
        } else {
            echo '<p class="error">Błąd: Plik menu "lista.html" nie istnieje. Nie można skonwertować pliku: ' . esc_html($plik) . '</p>';
        }
    }

    echo '<p class="success">Pliki zostały pomyślnie skonwertowane.</p>';
}


function pobierz_imie_nauczyciela_z_pliku($sciezka_do_pliku) {
    $plik = file_get_contents($sciezka_do_pliku);
    // Znajdź i pobierz imię nauczyciela z pliku HTML
    preg_match('/<span class="tytulnapis">(.+)<\/span>/', $plik, $matches);
    $imie_nauczyciela = isset($matches[1]) ? trim($matches[1]) : 'Nauczyciel';
    return $imie_nauczyciela;
}

// Zmodyfikuj funkcję konwertuj_plik
function konwertuj_plik($sciezka_do_pliku, $imie_nauczyciela) {
    $plik = file_get_contents($sciezka_do_pliku);

    // Znajdź wszystkie tabele planu lekcji w pliku
    preg_match_all('/<table[^>]*class="tabela"[^>]*>.*?<\/table>/s', $plik, $matches);

    // Sprawdź, czy znaleziono jakiekolwiek tabele
    if (empty($matches[0])) {
        echo '<p class="error">Błąd: Nie znaleziono tabel planu lekcji w pliku: ' . esc_html($sciezka_do_pliku) . '</p>';
        return;
    }

    // Przeszukaj znalezione tabele i dodaj tylko te o określonych parametrach
    foreach ($matches[0] as $tabela_html) {
        // Sprawdź, czy tabela ma określone parametry
        $oczekiwane_parametry = 'border="1" cellspacing="0" cellpadding="4" class="tabela"';
        if (strpos($tabela_html, $oczekiwane_parametry) !== false) {
            // Zmień nagłówek na odpowiedni (z użyciem stylów CSS)
            $naglowek_html = '<h2 style="color: #2B6CB0; margin-top:100px; text-align: center;">' . esc_html($imie_nauczyciela) . '</h2>';

            // Modyfikuj linki w treści tabeli
            $tabela_html = zmien_linki_w_tabeli($tabela_html);

            // Utwórz uproszczoną nazwę strony na podstawie nazwy pliku
            $nazwa_pliku = pathinfo($sciezka_do_pliku, PATHINFO_FILENAME);
            $uproszczona_nazwa_strony = sanitize_title($nazwa_pliku);

            // Dodaj przycisk drukowania na każdej stronie z planem
            $print_button = '<div style="text-align: left; margin-top: 5px; margin-left: 5px;" class="print-button"><button onclick="printTable()" style="padding: 10px; background-color: #2B6CB0; color: #fff; border: none;">Drukuj</button></div>';

            // Dodaj styl CSS na samym końcu pliku
            $css_block = '<style> /*style planu lekcji*/ .toggle-list, .col, .col2, .col3 { display: none; } .zglos { text-align: right; } .aktualizacja { text-align: right; } .toggle-list.show, .col, .col2, .col3 { display: block; } .tabela { width: 100%; overflow-x: auto; } table { width: 100%; border-collapse: collapse; } th, td { white-space: nowrap; } .tabela th, .tabela tr:first-child th { background-color: #215387; color: #fff; } .tabela td.nr, .tabela td.l:not(:empty):not(:has(a)), .tabela td.g:not(:empty):not(:has(a)) { background-color: #2B6CB0; color: #fff; } .tabela td.nr:empty, .tabela td.l:empty:not(:has(a)), .tabela td.g:empty:not(:has(a)) { background-color: transparent; color: inherit; } .tabela td.g:not(:empty):not(:has(a)) { background-color: #2B6CB0; color: #fff; } .tabela td.nr:not(:empty):not(:has(a)) { background-color: #215387; color: #fff; } .tabela td.l:empty:has(a), .tabela td.g:empty:has(a) { background-color: transparent; color: inherit; } .col { float: left; width: 18%; a { color: #fff; text-decoration: none; } a:hover { color: #669cd7; } background: #215387; border: 3px solid gray; } .col2 { float: right; width: 82%; text-align: center; } .col3 { float: right; justify-content: center; width: 82%;} .cont {} .toggle-header { color: #fff; cursor: pointer; } .toggle-list { list-style: none; padding: 0; max-height: 0; overflow: hidden; transition: max-height 0.5s ease-out; } .toggle-list.show { max-height: 1000px; transition: max-height 1s ease-in; } .content-container.site-container { width: 100%; max-width: 100%; } @media screen and (max-width: 750px) { .col { float: none; width: 100%; margin-bottom: 10px; white-space: nowrap; } .col2, .col3 { float: none; width: 100%; } .tabela { overflow-x: auto; } .zglos { text-align: center; } .aktualizacja { text-align: center; } } </style>';
            
            // Dodaj shortcode do treści strony z użyciem stylów CSS
            $shortcode_content = '<div style="text-align: center; margin-top: 5px;">';
            $shortcode_content .= '<h6 style="display: inline; font-size: 16px;">Plan obowiązuje od:</h6>';
            $shortcode_content .= '<h5 style="display: inline; margin-left: 5px; font-size: 18px;">[data_obowiazywania_shortcode] r.</h5></div>';
			
			// Zmień kolejność daty
			$data_test = current_time('mysql');
			$data_aktualizacji = date('d-m-Y H:i', strtotime($data_test));

			
			
            // Dodaj menu po lewej stronie tabeli
            $menu_html = pobierz_menu_lewe();
            $post_content = $css_block . $naglowek_html . '<div class="cont">' . '<div class="container">' . '<div class="col">' . $menu_html . '</div>' . '<div class="col2">' . '<div class="tabela">' . zmien_kolory_komorek($tabela_html) . '</div></div>' . '<div class="col3">' . $shortcode_content . '<div class="zglos"><h4><a href="/index.php/plan-contact" style="color: red; text-decoration: none;">Zgłoś błąd w planie</a></h4></div>' . '<div class="aktualizacja"> Aktualizacja: ' . $data_aktualizacji . '</div>' . $print_button . '</div>' . '<script src="/wp-content/plugins/timetable/printTableScript.js"></script>';
		

            // Dodanie informacji o stronie do bazy danych WordPress
            $post_data = array(
                'post_name'    => $uproszczona_nazwa_strony,
                'post_title'   => 'Plan lekcji - ' . esc_html($imie_nauczyciela),
                'post_content' => $post_content,
                'post_status'  => 'publish',
                'post_type'    => 'page',
                'post_date'    => current_time('mysql'), // Ustawia aktualny czas jako datę publikacji
            );
            $post_id = wp_insert_post($post_data);
            if (is_wp_error($post_id)) {
                echo '<p class="error">Błąd: Nie udało się utworzyć strony z pliku: ' . esc_html($sciezka_do_pliku) . '</p>';
            } else {
                dodaj_informacje_o_stronie($post_id);
            }
        }
    }
}

function zmien_kolory_komorek($tabela_html) {
    // Dodaj odpowiednie klasy CSS do komórek tabeli
    $tabela_html = preg_replace_callback('/<td class="l">(&nbsp;|\s*)<\/td>/', function($match) {
        return '<td class="l-neutral">' . $match[1] . '</td>';
    }, $tabela_html);

    $tabela_html = preg_replace_callback('/<td class="l">~([^~]+)~<\/td>/', function($match) {
        return '<td class="l-neutral">~' . esc_html($match[1]) . '~</td>';
    }, $tabela_html);

    return $tabela_html;
}

function zmien_linki_w_tabeli($tabela_html) {
    // Zmień linki w treści tabeli
    $tabela_html = preg_replace_callback('/<a\s+href="([^"]+\.html)"[^>]*>/', function($match) {
        $newHref = '/index.php/' . str_replace('.html', '', $match[1]);
        return '<a href="' . esc_url($newHref) . '">';
    }, $tabela_html);

    return $tabela_html;
}


function zmien_linki_w_menu($menu_html) {
    // Zmień linki w treści menu
    $menu_html = preg_replace_callback('/<a\s+href="plany\/([^"]+)"[^>]*>/', function($match) {
        // Usuń oryginalną ścieżkę /plany/ ze ścieżki pliku
        $newHref = '/index.php/' . str_replace('.html', '', $match[1]);
        return '<a href="' . esc_url($newHref) . '">';
    }, $menu_html);

    return $menu_html;
}


function dodaj_informacje_o_stronie($post_id) {
    $konwertowane_strony = get_option('konwertowane_strony', array());
    $konwertowane_strony[] = $post_id;
    update_option('konwertowane_strony', $konwertowane_strony);
}

// Dodaj shortcode [data_obowiazywania_shortcode]
add_shortcode('data_obowiazywania_shortcode', 'pobierz_date_obowiazywania_shortcode',);

function pobierz_date_obowiazywania_shortcode() {
    $data_obowiazywania = esc_attr(get_option('data_obowiazywania'));
    return '<time>' . esc_html($data_obowiazywania) . '</time>';
}

// Obsługa usuwania wszystkich skonwertowanych stron
if (isset($_POST['usun_wszystkie_strony'])) {
    usun_wszystkie_skonwertowane_strony();
}

function usun_wszystkie_skonwertowane_strony() {
    $konwertowane_strony = get_option('konwertowane_strony', array());
    
    foreach ($konwertowane_strony as $post_id) {
        wp_delete_post($post_id, true); // Usuń stronę (do kosza)
    }

    delete_option('konwertowane_strony'); // Wyczyść listę skonwertowanych stron
    echo '<p class="success">Wszystkie skonwertowane strony zostały pomyślnie usunięte.</p>';
}
?>