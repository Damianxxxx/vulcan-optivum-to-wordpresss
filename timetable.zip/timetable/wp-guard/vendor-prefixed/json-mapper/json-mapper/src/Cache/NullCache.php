<?php
/**
 * @license MIT
 *
 * Modified by Philo Hermans on 13-January-2024 using Strauss.
 * @see https://github.com/BrianHenryIE/strauss
 */

namespace Anystack\WPGuard\V001\JsonMapper\Cache;

use Psr\SimpleCache\CacheInterface;
use Anystack\WPGuard\V001\Symfony\Component\Cache\Adapter\NullAdapter;
use Anystack\WPGuard\V001\Symfony\Component\Cache\Psr16Cache;

class NullCache extends Psr16Cache implements CacheInterface
{

    public function __construct()
    {
        parent::__construct(new NullAdapter());
    }
}