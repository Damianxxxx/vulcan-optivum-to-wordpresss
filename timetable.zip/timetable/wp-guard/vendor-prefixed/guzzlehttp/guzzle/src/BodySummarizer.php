<?php
/**
 * @license MIT
 *
 * Modified by Philo Hermans on 13-January-2024 using Strauss.
 * @see https://github.com/BrianHenryIE/strauss
 */

namespace Anystack\WPGuard\V001\GuzzleHttp;

use Psr\Http\Message\MessageInterface;

final class BodySummarizer implements BodySummarizerInterface
{
    /**
     * @var int|null
     */
    private $truncateAt;

    public function __construct(int $truncateAt = null)
    {
        $this->truncateAt = $truncateAt;
    }

    /**
     * Returns a summarized message body.
     */
    public function summarize(MessageInterface $message): ?string
    {
        return $this->truncateAt === null
            ? \Anystack\WPGuard\V001\GuzzleHttp\Psr7\Message::bodySummary($message)
            : \Anystack\WPGuard\V001\GuzzleHttp\Psr7\Message::bodySummary($message, $this->truncateAt);
    }
}
