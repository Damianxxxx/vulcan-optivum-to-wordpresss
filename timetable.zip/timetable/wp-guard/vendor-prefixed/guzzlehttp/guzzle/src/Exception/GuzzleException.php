<?php
/**
 * @license MIT
 *
 * Modified by Philo Hermans on 13-January-2024 using Strauss.
 * @see https://github.com/BrianHenryIE/strauss
 */

namespace Anystack\WPGuard\V001\GuzzleHttp\Exception;

use Psr\Http\Client\ClientExceptionInterface;

interface GuzzleException extends ClientExceptionInterface
{
}
